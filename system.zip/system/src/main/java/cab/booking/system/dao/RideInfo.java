package cab.booking.system.dao;

public class RideInfo {

}
